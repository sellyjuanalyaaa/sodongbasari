import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
export const index = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/institutions/{institution}/members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
index.url = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { institution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { institution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                }

    return index.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
index.get = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
index.head = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
    const indexForm = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
        indexForm.get = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::index
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:14
 * @route '/admin/institutions/{institution}/members'
 */
        indexForm.head = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
export const create = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/institutions/{institution}/members/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
create.url = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { institution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { institution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                }

    return create.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
create.get = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
create.head = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
    const createForm = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
        createForm.get = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::create
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:23
 * @route '/admin/institutions/{institution}/members/create'
 */
        createForm.head = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::store
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:30
 * @route '/admin/institutions/{institution}/members'
 */
export const store = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/institutions/{institution}/members',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::store
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:30
 * @route '/admin/institutions/{institution}/members'
 */
store.url = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { institution: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { institution: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                }

    return store.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::store
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:30
 * @route '/admin/institutions/{institution}/members'
 */
store.post = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::store
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:30
 * @route '/admin/institutions/{institution}/members'
 */
    const storeForm = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::store
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:30
 * @route '/admin/institutions/{institution}/members'
 */
        storeForm.post = (args: { institution: number | { id: number } } | [institution: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
export const show = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/institutions/{institution}/members/{member}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
show.url = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: args.institution,
                                member: args.member,
                }

    return show.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
show.get = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
show.head = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
    const showForm = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
        showForm.get = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::show
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:0
 * @route '/admin/institutions/{institution}/members/{member}'
 */
        showForm.head = (args: { institution: string | number, member: string | number } | [institution: string | number, member: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
export const edit = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/institutions/{institution}/members/{member}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
edit.url = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                                member: typeof args.member === 'object'
                ? args.member.id
                : args.member,
                }

    return edit.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
edit.get = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
edit.head = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
    const editForm = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
        editForm.get = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::edit
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:57
 * @route '/admin/institutions/{institution}/members/{member}/edit'
 */
        editForm.head = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
export const update = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/institutions/{institution}/members/{member}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
update.url = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                                member: typeof args.member === 'object'
                ? args.member.id
                : args.member,
                }

    return update.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
update.put = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
update.patch = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
    const updateForm = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
        updateForm.put = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::update
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:65
 * @route '/admin/institutions/{institution}/members/{member}'
 */
        updateForm.patch = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::destroy
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:105
 * @route '/admin/institutions/{institution}/members/{member}'
 */
export const destroy = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/institutions/{institution}/members/{member}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::destroy
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:105
 * @route '/admin/institutions/{institution}/members/{member}'
 */
destroy.url = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    institution: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        institution: typeof args.institution === 'object'
                ? args.institution.id
                : args.institution,
                                member: typeof args.member === 'object'
                ? args.member.id
                : args.member,
                }

    return destroy.definition.url
            .replace('{institution}', parsedArgs.institution.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::destroy
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:105
 * @route '/admin/institutions/{institution}/members/{member}'
 */
destroy.delete = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::destroy
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:105
 * @route '/admin/institutions/{institution}/members/{member}'
 */
    const destroyForm = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\InstitutionMemberController::destroy
 * @see app/Http/Controllers/Admin/InstitutionMemberController.php:105
 * @route '/admin/institutions/{institution}/members/{member}'
 */
        destroyForm.delete = (args: { institution: number | { id: number }, member: number | { id: number } } | [institution: number | { id: number }, member: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const InstitutionMemberController = { index, create, store, show, edit, update, destroy }

export default InstitutionMemberController