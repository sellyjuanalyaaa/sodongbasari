import DashboardController from './DashboardController'
import PostController from './PostController'
import CategoryController from './CategoryController'
import SliderController from './SliderController'
import PotentialController from './PotentialController'
import PotentialCategoryController from './PotentialCategoryController'
import InstitutionController from './InstitutionController'
import InstitutionMemberController from './InstitutionMemberController'
import DemographicController from './DemographicController'
import BudgetController from './BudgetController'
import StatisticController from './StatisticController'
import VillageOfficialController from './VillageOfficialController'
import FormerVillageHeadController from './FormerVillageHeadController'
import HomeStatisticController from './HomeStatisticController'
import VisitorController from './VisitorController'
import NotificationController from './NotificationController'
import VillageInfoController from './VillageInfoController'
import HeroController from './HeroController'
import UserController from './UserController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
PostController: Object.assign(PostController, PostController),
CategoryController: Object.assign(CategoryController, CategoryController),
SliderController: Object.assign(SliderController, SliderController),
PotentialController: Object.assign(PotentialController, PotentialController),
PotentialCategoryController: Object.assign(PotentialCategoryController, PotentialCategoryController),
InstitutionController: Object.assign(InstitutionController, InstitutionController),
InstitutionMemberController: Object.assign(InstitutionMemberController, InstitutionMemberController),
DemographicController: Object.assign(DemographicController, DemographicController),
BudgetController: Object.assign(BudgetController, BudgetController),
StatisticController: Object.assign(StatisticController, StatisticController),
VillageOfficialController: Object.assign(VillageOfficialController, VillageOfficialController),
FormerVillageHeadController: Object.assign(FormerVillageHeadController, FormerVillageHeadController),
HomeStatisticController: Object.assign(HomeStatisticController, HomeStatisticController),
VisitorController: Object.assign(VisitorController, VisitorController),
NotificationController: Object.assign(NotificationController, NotificationController),
VillageInfoController: Object.assign(VillageInfoController, VillageInfoController),
HeroController: Object.assign(HeroController, HeroController),
UserController: Object.assign(UserController, UserController),
}

export default Admin