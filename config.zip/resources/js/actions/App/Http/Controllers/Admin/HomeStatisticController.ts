import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/home-statistics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::index
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:13
 * @route '/admin/home-statistics'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/home-statistics/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::create
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:24
 * @route '/admin/home-statistics/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::store
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:32
 * @route '/admin/home-statistics'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/home-statistics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::store
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:32
 * @route '/admin/home-statistics'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::store
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:32
 * @route '/admin/home-statistics'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::store
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:32
 * @route '/admin/home-statistics'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::store
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:32
 * @route '/admin/home-statistics'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
export const show = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/home-statistics/{home_statistic}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
show.url = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { home_statistic: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    home_statistic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        home_statistic: args.home_statistic,
                }

    return show.definition.url
            .replace('{home_statistic}', parsedArgs.home_statistic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
show.get = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
show.head = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
    const showForm = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
        showForm.get = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::show
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:0
 * @route '/admin/home-statistics/{home_statistic}'
 */
        showForm.head = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
export const edit = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/home-statistics/{home_statistic}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
edit.url = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { home_statistic: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    home_statistic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        home_statistic: args.home_statistic,
                }

    return edit.definition.url
            .replace('{home_statistic}', parsedArgs.home_statistic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
edit.get = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
edit.head = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
    const editForm = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
        editForm.get = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::edit
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:57
 * @route '/admin/home-statistics/{home_statistic}/edit'
 */
        editForm.head = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
export const update = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/home-statistics/{home_statistic}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
update.url = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { home_statistic: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    home_statistic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        home_statistic: args.home_statistic,
                }

    return update.definition.url
            .replace('{home_statistic}', parsedArgs.home_statistic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
update.put = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
update.patch = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
    const updateForm = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
        updateForm.put = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::update
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:68
 * @route '/admin/home-statistics/{home_statistic}'
 */
        updateForm.patch = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::destroy
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:96
 * @route '/admin/home-statistics/{home_statistic}'
 */
export const destroy = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/home-statistics/{home_statistic}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::destroy
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:96
 * @route '/admin/home-statistics/{home_statistic}'
 */
destroy.url = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { home_statistic: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    home_statistic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        home_statistic: args.home_statistic,
                }

    return destroy.definition.url
            .replace('{home_statistic}', parsedArgs.home_statistic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HomeStatisticController::destroy
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:96
 * @route '/admin/home-statistics/{home_statistic}'
 */
destroy.delete = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::destroy
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:96
 * @route '/admin/home-statistics/{home_statistic}'
 */
    const destroyForm = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HomeStatisticController::destroy
 * @see app/Http/Controllers/Admin/HomeStatisticController.php:96
 * @route '/admin/home-statistics/{home_statistic}'
 */
        destroyForm.delete = (args: { home_statistic: string | number } | [home_statistic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const HomeStatisticController = { index, create, store, show, edit, update, destroy }

export default HomeStatisticController