import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::index
 * @see app/Http/Controllers/PublicController.php:27
 * @route '/'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
export const sodongBasari = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sodongBasari.url(options),
    method: 'get',
})

sodongBasari.definition = {
    methods: ["get","head"],
    url: '/sodong-basari',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
sodongBasari.url = (options?: RouteQueryOptions) => {
    return sodongBasari.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
sodongBasari.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sodongBasari.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
sodongBasari.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sodongBasari.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
    const sodongBasariForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sodongBasari.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
        sodongBasariForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sodongBasari.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::sodongBasari
 * @see app/Http/Controllers/PublicController.php:49
 * @route '/sodong-basari'
 */
        sodongBasariForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sodongBasari.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sodongBasari.form = sodongBasariForm
/**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
export const statistics = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(options),
    method: 'get',
})

statistics.definition = {
    methods: ["get","head"],
    url: '/statistik',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
statistics.url = (options?: RouteQueryOptions) => {
    return statistics.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
statistics.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statistics.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
statistics.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statistics.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
    const statisticsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: statistics.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
        statisticsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::statistics
 * @see app/Http/Controllers/PublicController.php:105
 * @route '/statistik'
 */
        statisticsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: statistics.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    statistics.form = statisticsForm
/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
export const potentials = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentials.url(options),
    method: 'get',
})

potentials.definition = {
    methods: ["get","head"],
    url: '/potensi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
potentials.url = (options?: RouteQueryOptions) => {
    return potentials.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
potentials.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentials.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
potentials.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: potentials.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
    const potentialsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: potentials.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
        potentialsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentials.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:58
 * @route '/potensi'
 */
        potentialsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentials.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    potentials.form = potentialsForm
/**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
export const potentialShow = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentialShow.url(args, options),
    method: 'get',
})

potentialShow.definition = {
    methods: ["get","head"],
    url: '/potensi/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
potentialShow.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return potentialShow.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
potentialShow.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentialShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
potentialShow.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: potentialShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
    const potentialShowForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: potentialShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
        potentialShowForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentialShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::potentialShow
 * @see app/Http/Controllers/PublicController.php:92
 * @route '/potensi/{id}'
 */
        potentialShowForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentialShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    potentialShow.form = potentialShowForm
/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
export const news = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

news.definition = {
    methods: ["get","head"],
    url: '/news',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
news.url = (options?: RouteQueryOptions) => {
    return news.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
news.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
news.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: news.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
    const newsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: news.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
        newsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: news.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:123
 * @route '/news'
 */
        newsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: news.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    news.form = newsForm
/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
export const newsShow = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})

newsShow.definition = {
    methods: ["get","head"],
    url: '/news/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
newsShow.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return newsShow.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
newsShow.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
newsShow.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: newsShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
    const newsShowForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: newsShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
        newsShowForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: newsShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:136
 * @route '/news/{slug}'
 */
        newsShowForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: newsShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    newsShow.form = newsShowForm
/**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
export const institutionShow = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: institutionShow.url(args, options),
    method: 'get',
})

institutionShow.definition = {
    methods: ["get","head"],
    url: '/lembaga/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
institutionShow.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return institutionShow.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
institutionShow.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: institutionShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
institutionShow.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: institutionShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
    const institutionShowForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: institutionShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
        institutionShowForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: institutionShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::institutionShow
 * @see app/Http/Controllers/PublicController.php:149
 * @route '/lembaga/{id}'
 */
        institutionShowForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: institutionShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    institutionShow.form = institutionShowForm
const PublicController = { index, sodongBasari, statistics, potentials, potentialShow, news, newsShow, institutionShow }

export default PublicController