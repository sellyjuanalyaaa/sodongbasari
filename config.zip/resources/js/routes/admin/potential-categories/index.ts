import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/potential-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::index
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:12
 * @route '/admin/potential-categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/potential-categories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::create
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:21
 * @route '/admin/potential-categories/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::store
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:26
 * @route '/admin/potential-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/potential-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::store
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:26
 * @route '/admin/potential-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::store
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:26
 * @route '/admin/potential-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::store
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:26
 * @route '/admin/potential-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::store
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:26
 * @route '/admin/potential-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
export const show = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/potential-categories/{potential_category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
show.url = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { potential_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    potential_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        potential_category: args.potential_category,
                }

    return show.definition.url
            .replace('{potential_category}', parsedArgs.potential_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
show.get = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
show.head = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
    const showForm = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
        showForm.get = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::show
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:0
 * @route '/admin/potential-categories/{potential_category}'
 */
        showForm.head = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
export const edit = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/potential-categories/{potential_category}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
edit.url = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { potential_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    potential_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        potential_category: args.potential_category,
                }

    return edit.definition.url
            .replace('{potential_category}', parsedArgs.potential_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
edit.get = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
edit.head = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
    const editForm = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
        editForm.get = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::edit
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:41
 * @route '/admin/potential-categories/{potential_category}/edit'
 */
        editForm.head = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
export const update = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/potential-categories/{potential_category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
update.url = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { potential_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    potential_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        potential_category: args.potential_category,
                }

    return update.definition.url
            .replace('{potential_category}', parsedArgs.potential_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
update.put = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
update.patch = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
    const updateForm = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
        updateForm.put = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::update
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:48
 * @route '/admin/potential-categories/{potential_category}'
 */
        updateForm.patch = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::destroy
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:63
 * @route '/admin/potential-categories/{potential_category}'
 */
export const destroy = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/potential-categories/{potential_category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::destroy
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:63
 * @route '/admin/potential-categories/{potential_category}'
 */
destroy.url = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { potential_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    potential_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        potential_category: args.potential_category,
                }

    return destroy.definition.url
            .replace('{potential_category}', parsedArgs.potential_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::destroy
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:63
 * @route '/admin/potential-categories/{potential_category}'
 */
destroy.delete = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::destroy
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:63
 * @route '/admin/potential-categories/{potential_category}'
 */
    const destroyForm = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\PotentialCategoryController::destroy
 * @see app/Http/Controllers/Admin/PotentialCategoryController.php:63
 * @route '/admin/potential-categories/{potential_category}'
 */
        destroyForm.delete = (args: { potential_category: string | number } | [potential_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const potentialCategories = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default potentialCategories