import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import posts from './posts'
import categories from './categories'
import sliders from './sliders'
import potentials from './potentials'
import potentialCategories from './potential-categories'
import institutions from './institutions'
import demographics from './demographics'
import budgets from './budgets'
import statistics from './statistics'
import officials from './officials'
import formerVillageHeads from './former-village-heads'
import homeStatistics from './home-statistics'
import visitors from './visitors'
import notifications from './notifications'
import villageInfo from './village-info'
import hero from './hero'
import users from './users'
/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DashboardController::dashboard
 * @see app/Http/Controllers/Admin/DashboardController.php:15
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
posts: Object.assign(posts, posts),
categories: Object.assign(categories, categories),
sliders: Object.assign(sliders, sliders),
potentials: Object.assign(potentials, potentials),
potentialCategories: Object.assign(potentialCategories, potentialCategories),
institutions: Object.assign(institutions, institutions),
demographics: Object.assign(demographics, demographics),
budgets: Object.assign(budgets, budgets),
statistics: Object.assign(statistics, statistics),
officials: Object.assign(officials, officials),
formerVillageHeads: Object.assign(formerVillageHeads, formerVillageHeads),
homeStatistics: Object.assign(homeStatistics, homeStatistics),
visitors: Object.assign(visitors, visitors),
notifications: Object.assign(notifications, notifications),
villageInfo: Object.assign(villageInfo, villageInfo),
hero: Object.assign(hero, hero),
users: Object.assign(users, users),
}

export default admin