import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/budgets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BudgetController::index
 * @see app/Http/Controllers/Admin/BudgetController.php:12
 * @route '/admin/budgets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/budgets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BudgetController::create
 * @see app/Http/Controllers/Admin/BudgetController.php:20
 * @route '/admin/budgets/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::store
 * @see app/Http/Controllers/Admin/BudgetController.php:25
 * @route '/admin/budgets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/budgets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::store
 * @see app/Http/Controllers/Admin/BudgetController.php:25
 * @route '/admin/budgets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::store
 * @see app/Http/Controllers/Admin/BudgetController.php:25
 * @route '/admin/budgets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::store
 * @see app/Http/Controllers/Admin/BudgetController.php:25
 * @route '/admin/budgets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::store
 * @see app/Http/Controllers/Admin/BudgetController.php:25
 * @route '/admin/budgets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
export const show = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/budgets/{budget}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
show.url = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { budget: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    budget: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        budget: args.budget,
                }

    return show.definition.url
            .replace('{budget}', parsedArgs.budget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
show.get = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
show.head = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
    const showForm = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
        showForm.get = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BudgetController::show
 * @see app/Http/Controllers/Admin/BudgetController.php:0
 * @route '/admin/budgets/{budget}'
 */
        showForm.head = (args: { budget: string | number } | [budget: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
export const edit = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/budgets/{budget}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
edit.url = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { budget: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { budget: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    budget: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        budget: typeof args.budget === 'object'
                ? args.budget.id
                : args.budget,
                }

    return edit.definition.url
            .replace('{budget}', parsedArgs.budget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
edit.get = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
edit.head = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
    const editForm = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
        editForm.get = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BudgetController::edit
 * @see app/Http/Controllers/Admin/BudgetController.php:38
 * @route '/admin/budgets/{budget}/edit'
 */
        editForm.head = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
export const update = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/budgets/{budget}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
update.url = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { budget: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { budget: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    budget: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        budget: typeof args.budget === 'object'
                ? args.budget.id
                : args.budget,
                }

    return update.definition.url
            .replace('{budget}', parsedArgs.budget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
update.put = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
update.patch = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
    const updateForm = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
        updateForm.put = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\BudgetController::update
 * @see app/Http/Controllers/Admin/BudgetController.php:45
 * @route '/admin/budgets/{budget}'
 */
        updateForm.patch = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\BudgetController::destroy
 * @see app/Http/Controllers/Admin/BudgetController.php:58
 * @route '/admin/budgets/{budget}'
 */
export const destroy = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/budgets/{budget}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\BudgetController::destroy
 * @see app/Http/Controllers/Admin/BudgetController.php:58
 * @route '/admin/budgets/{budget}'
 */
destroy.url = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { budget: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { budget: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    budget: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        budget: typeof args.budget === 'object'
                ? args.budget.id
                : args.budget,
                }

    return destroy.definition.url
            .replace('{budget}', parsedArgs.budget.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BudgetController::destroy
 * @see app/Http/Controllers/Admin/BudgetController.php:58
 * @route '/admin/budgets/{budget}'
 */
destroy.delete = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\BudgetController::destroy
 * @see app/Http/Controllers/Admin/BudgetController.php:58
 * @route '/admin/budgets/{budget}'
 */
    const destroyForm = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BudgetController::destroy
 * @see app/Http/Controllers/Admin/BudgetController.php:58
 * @route '/admin/budgets/{budget}'
 */
        destroyForm.delete = (args: { budget: number | { id: number } } | [budget: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const budgets = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default budgets