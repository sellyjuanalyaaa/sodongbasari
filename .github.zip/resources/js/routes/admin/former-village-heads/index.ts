import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/former-village-heads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::index
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:13
 * @route '/admin/former-village-heads'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/former-village-heads/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::create
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:22
 * @route '/admin/former-village-heads/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::store
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:27
 * @route '/admin/former-village-heads'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/former-village-heads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::store
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:27
 * @route '/admin/former-village-heads'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::store
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:27
 * @route '/admin/former-village-heads'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::store
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:27
 * @route '/admin/former-village-heads'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::store
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:27
 * @route '/admin/former-village-heads'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
export const show = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/former-village-heads/{former_village_head}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
show.url = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { former_village_head: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    former_village_head: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        former_village_head: args.former_village_head,
                }

    return show.definition.url
            .replace('{former_village_head}', parsedArgs.former_village_head.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
show.get = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
show.head = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
    const showForm = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
        showForm.get = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::show
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:0
 * @route '/admin/former-village-heads/{former_village_head}'
 */
        showForm.head = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
export const edit = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/former-village-heads/{former_village_head}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
edit.url = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { former_village_head: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    former_village_head: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        former_village_head: args.former_village_head,
                }

    return edit.definition.url
            .replace('{former_village_head}', parsedArgs.former_village_head.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
edit.get = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
edit.head = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
    const editForm = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
        editForm.get = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::edit
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:48
 * @route '/admin/former-village-heads/{former_village_head}/edit'
 */
        editForm.head = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
export const update = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/former-village-heads/{former_village_head}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
update.url = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { former_village_head: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    former_village_head: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        former_village_head: args.former_village_head,
                }

    return update.definition.url
            .replace('{former_village_head}', parsedArgs.former_village_head.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
update.put = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
update.patch = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
    const updateForm = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
        updateForm.put = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::update
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:55
 * @route '/admin/former-village-heads/{former_village_head}'
 */
        updateForm.patch = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::destroy
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:79
 * @route '/admin/former-village-heads/{former_village_head}'
 */
export const destroy = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/former-village-heads/{former_village_head}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::destroy
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:79
 * @route '/admin/former-village-heads/{former_village_head}'
 */
destroy.url = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { former_village_head: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    former_village_head: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        former_village_head: args.former_village_head,
                }

    return destroy.definition.url
            .replace('{former_village_head}', parsedArgs.former_village_head.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::destroy
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:79
 * @route '/admin/former-village-heads/{former_village_head}'
 */
destroy.delete = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::destroy
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:79
 * @route '/admin/former-village-heads/{former_village_head}'
 */
    const destroyForm = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\FormerVillageHeadController::destroy
 * @see app/Http/Controllers/Admin/FormerVillageHeadController.php:79
 * @route '/admin/former-village-heads/{former_village_head}'
 */
        destroyForm.delete = (args: { former_village_head: string | number } | [former_village_head: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const formerVillageHeads = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default formerVillageHeads