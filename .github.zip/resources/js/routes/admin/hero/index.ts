import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/hero-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\HeroController::edit
 * @see app/Http/Controllers/Admin/HeroController.php:13
 * @route '/admin/hero-settings'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\HeroController::store
 * @see app/Http/Controllers/Admin/HeroController.php:20
 * @route '/admin/hero-settings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/hero-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::store
 * @see app/Http/Controllers/Admin/HeroController.php:20
 * @route '/admin/hero-settings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::store
 * @see app/Http/Controllers/Admin/HeroController.php:20
 * @route '/admin/hero-settings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::store
 * @see app/Http/Controllers/Admin/HeroController.php:20
 * @route '/admin/hero-settings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::store
 * @see app/Http/Controllers/Admin/HeroController.php:20
 * @route '/admin/hero-settings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\HeroController::destroy
 * @see app/Http/Controllers/Admin/HeroController.php:39
 * @route '/admin/hero-settings/{heroImage}'
 */
export const destroy = (args: { heroImage: number | { id: number } } | [heroImage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/hero-settings/{heroImage}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\HeroController::destroy
 * @see app/Http/Controllers/Admin/HeroController.php:39
 * @route '/admin/hero-settings/{heroImage}'
 */
destroy.url = (args: { heroImage: number | { id: number } } | [heroImage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { heroImage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { heroImage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    heroImage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        heroImage: typeof args.heroImage === 'object'
                ? args.heroImage.id
                : args.heroImage,
                }

    return destroy.definition.url
            .replace('{heroImage}', parsedArgs.heroImage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\HeroController::destroy
 * @see app/Http/Controllers/Admin/HeroController.php:39
 * @route '/admin/hero-settings/{heroImage}'
 */
destroy.delete = (args: { heroImage: number | { id: number } } | [heroImage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\HeroController::destroy
 * @see app/Http/Controllers/Admin/HeroController.php:39
 * @route '/admin/hero-settings/{heroImage}'
 */
    const destroyForm = (args: { heroImage: number | { id: number } } | [heroImage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\HeroController::destroy
 * @see app/Http/Controllers/Admin/HeroController.php:39
 * @route '/admin/hero-settings/{heroImage}'
 */
        destroyForm.delete = (args: { heroImage: number | { id: number } } | [heroImage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const hero = {
    edit: Object.assign(edit, edit),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default hero