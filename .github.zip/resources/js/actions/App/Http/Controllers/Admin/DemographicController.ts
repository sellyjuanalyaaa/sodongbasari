import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/demographics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DemographicController::index
 * @see app/Http/Controllers/Admin/DemographicController.php:12
 * @route '/admin/demographics'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/demographics/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DemographicController::create
 * @see app/Http/Controllers/Admin/DemographicController.php:20
 * @route '/admin/demographics/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::store
 * @see app/Http/Controllers/Admin/DemographicController.php:25
 * @route '/admin/demographics'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/demographics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::store
 * @see app/Http/Controllers/Admin/DemographicController.php:25
 * @route '/admin/demographics'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::store
 * @see app/Http/Controllers/Admin/DemographicController.php:25
 * @route '/admin/demographics'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::store
 * @see app/Http/Controllers/Admin/DemographicController.php:25
 * @route '/admin/demographics'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::store
 * @see app/Http/Controllers/Admin/DemographicController.php:25
 * @route '/admin/demographics'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
export const show = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/demographics/{demographic}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
show.url = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { demographic: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    demographic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        demographic: args.demographic,
                }

    return show.definition.url
            .replace('{demographic}', parsedArgs.demographic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
show.get = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
show.head = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
    const showForm = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
        showForm.get = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DemographicController::show
 * @see app/Http/Controllers/Admin/DemographicController.php:0
 * @route '/admin/demographics/{demographic}'
 */
        showForm.head = (args: { demographic: string | number } | [demographic: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
export const edit = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/demographics/{demographic}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
edit.url = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { demographic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { demographic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    demographic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        demographic: typeof args.demographic === 'object'
                ? args.demographic.id
                : args.demographic,
                }

    return edit.definition.url
            .replace('{demographic}', parsedArgs.demographic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
edit.get = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
edit.head = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
    const editForm = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
        editForm.get = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DemographicController::edit
 * @see app/Http/Controllers/Admin/DemographicController.php:48
 * @route '/admin/demographics/{demographic}/edit'
 */
        editForm.head = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
export const update = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/demographics/{demographic}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
update.url = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { demographic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { demographic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    demographic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        demographic: typeof args.demographic === 'object'
                ? args.demographic.id
                : args.demographic,
                }

    return update.definition.url
            .replace('{demographic}', parsedArgs.demographic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
update.put = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
update.patch = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
    const updateForm = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
        updateForm.put = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:55
 * @route '/admin/demographics/{demographic}'
 */
        updateForm.patch = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\DemographicController::destroy
 * @see app/Http/Controllers/Admin/DemographicController.php:71
 * @route '/admin/demographics/{demographic}'
 */
export const destroy = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/demographics/{demographic}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::destroy
 * @see app/Http/Controllers/Admin/DemographicController.php:71
 * @route '/admin/demographics/{demographic}'
 */
destroy.url = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { demographic: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { demographic: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    demographic: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        demographic: typeof args.demographic === 'object'
                ? args.demographic.id
                : args.demographic,
                }

    return destroy.definition.url
            .replace('{demographic}', parsedArgs.demographic.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::destroy
 * @see app/Http/Controllers/Admin/DemographicController.php:71
 * @route '/admin/demographics/{demographic}'
 */
destroy.delete = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::destroy
 * @see app/Http/Controllers/Admin/DemographicController.php:71
 * @route '/admin/demographics/{demographic}'
 */
    const destroyForm = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::destroy
 * @see app/Http/Controllers/Admin/DemographicController.php:71
 * @route '/admin/demographics/{demographic}'
 */
        destroyForm.delete = (args: { demographic: number | { id: number } } | [demographic: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DemographicController = { index, create, store, show, edit, update, destroy }

export default DemographicController