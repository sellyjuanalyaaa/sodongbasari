import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/officials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:13
 * @route '/admin/officials'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/officials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:22
 * @route '/admin/officials/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:29
 * @route '/admin/officials'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/officials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:29
 * @route '/admin/officials'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:29
 * @route '/admin/officials'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:29
 * @route '/admin/officials'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:29
 * @route '/admin/officials'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
export const show = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/officials/{official}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
show.url = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { official: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        official: args.official,
                }

    return show.definition.url
            .replace('{official}', parsedArgs.official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
show.get = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
show.head = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
    const showForm = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
        showForm.get = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:0
 * @route '/admin/officials/{official}'
 */
        showForm.head = (args: { official: string | number } | [official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
export const edit = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/officials/{official}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
edit.url = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { official: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { official: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        official: typeof args.official === 'object'
                ? args.official.id
                : args.official,
                }

    return edit.definition.url
            .replace('{official}', parsedArgs.official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
edit.get = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
edit.head = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
    const editForm = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
        editForm.get = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:48
 * @route '/admin/officials/{official}/edit'
 */
        editForm.head = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
export const update = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/officials/{official}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
update.url = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { official: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { official: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        official: typeof args.official === 'object'
                ? args.official.id
                : args.official,
                }

    return update.definition.url
            .replace('{official}', parsedArgs.official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
update.put = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
update.patch = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
    const updateForm = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
        updateForm.put = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:55
 * @route '/admin/officials/{official}'
 */
        updateForm.patch = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:78
 * @route '/admin/officials/{official}'
 */
export const destroy = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/officials/{official}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:78
 * @route '/admin/officials/{official}'
 */
destroy.url = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { official: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { official: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        official: typeof args.official === 'object'
                ? args.official.id
                : args.official,
                }

    return destroy.definition.url
            .replace('{official}', parsedArgs.official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:78
 * @route '/admin/officials/{official}'
 */
destroy.delete = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:78
 * @route '/admin/officials/{official}'
 */
    const destroyForm = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:78
 * @route '/admin/officials/{official}'
 */
        destroyForm.delete = (args: { official: number | { id: number } } | [official: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const VillageOfficialController = { index, create, store, show, edit, update, destroy }

export default VillageOfficialController