import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/visitors',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VisitorController::index
 * @see app/Http/Controllers/Admin/VisitorController.php:12
 * @route '/admin/visitors'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const VisitorController = { index }

export default VisitorController